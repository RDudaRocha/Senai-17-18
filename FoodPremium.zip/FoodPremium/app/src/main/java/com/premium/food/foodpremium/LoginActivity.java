package com.premium.food.foodpremium;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;



public class LoginActivity extends AppCompatActivity{

    EditText l1;
    EditText l2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        l1 = (EditText) findViewById(R.id.email);
        l2 = (EditText) findViewById(R.id.password);
    };

    public void checar(View v){

        String email = l1.getText().toString().trim();
        String pass = l2.getText().toString().trim();
        if((email.equals("fpadm@gmail.com"))&&(pass.equals("edafp"))){
            Intent Main2Activity = new Intent(this, Main2Activity.class);
            startActivity(Main2Activity);
        }else{
            Toast.makeText(getApplicationContext(),"Email ou Senha invalido", Toast.LENGTH_SHORT).show();
        }
    }

}

